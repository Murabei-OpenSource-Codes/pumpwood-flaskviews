"""Module associated with Flask/SQLAlchemy models."""
from .general import FlaskPumpWoodBaseModel


__all__ = [
    FlaskPumpWoodBaseModel
]
