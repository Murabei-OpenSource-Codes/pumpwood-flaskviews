"""Module with inspection of sqlalchemy aux functions."""
from .models import model_has_column

__all__ = [model_has_column]
